-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2016 at 10:37 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `osiguranje`
--

-- --------------------------------------------------------

--
-- Table structure for table `klijent`
--

CREATE TABLE IF NOT EXISTS `klijent` (
  `id_klijent` int(11) NOT NULL AUTO_INCREMENT,
  `korisnicko_ime` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `ime` varchar(45) DEFAULT NULL,
  `prezime` varchar(45) DEFAULT NULL,
  `starost` int(11) DEFAULT NULL,
  `mesto_rodjenja` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id_klijent`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `klijent`
--

INSERT INTO `klijent` (`id_klijent`, `korisnicko_ime`, `password`, `ime`, `prezime`, `starost`, `mesto_rodjenja`, `email`, `status`) VALUES
(1, 'admin', 'admin', 'Stefan', 'Sokolovic', 22, 'Leskovac', 'sokol.94@outlook.com', 1),
(2, 'user', 'user', 'Jovan', 'Jovanovic', 22, 'Nis', 'joca@gmail.com', 0),
(3, 'milan', 'milan', 'Milan', 'Milanovic', 25, 'Beograd', 'milanca@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `osiguranja`
--

CREATE TABLE IF NOT EXISTS `osiguranja` (
  `id_osiguranja` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(45) DEFAULT NULL,
  `informacije` text,
  `trajanje` int(11) DEFAULT NULL,
  `mesecna_rata` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_osiguranja`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `osiguranja`
--

INSERT INTO `osiguranja` (`id_osiguranja`, `ime`, `informacije`, `trajanje`, `mesecna_rata`) VALUES
(1, 'Zivotno osiguranje', 'Ovo osiguranje jeste, koje predvida isplatu novca u slucaju smrti nasledniku ili onom koga je osigurani naznacio.', 10, 800),
(2, 'Zdravstveno osiguranje', 'Ovo osiguranje pokriva predvidene troskove lecenja, lekova i pomagala za osiguranoga.', 8, 300),
(3, 'Osiguranje imovine', 'Ovo osiguranje obezbeduje osiguranje od pozara, provale, zemljotresa, poplave i slicnih dogadjaja.', 5, 200),
(4, 'Penzijsko osiguranje', 'Ovo osiguranje obezbedjuje dohodak u starosti', 15, 400),
(5, 'Osiguranje automobila', 'Ovo osiguranje moze obuhvatati kako osiguranje od stete na vozilu osiguranog, tako i osiguranje od njegove odgovornosti za pricinjenu stetu', 2, 450);

-- --------------------------------------------------------

--
-- Table structure for table `radnik`
--

CREATE TABLE IF NOT EXISTS `radnik` (
  `id_radnik` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(45) DEFAULT NULL,
  `prezime` varchar(45) DEFAULT NULL,
  `staz` int(11) DEFAULT NULL,
  `plata` int(11) DEFAULT NULL,
  `radno_mesto` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_radnik`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `radnik`
--

INSERT INTO `radnik` (`id_radnik`, `ime`, `prezime`, `staz`, `plata`, `radno_mesto`) VALUES
(1, 'Jovana', 'Ivic', 10, 30000, 'sekretar'),
(2, 'Milan', 'Sokolovic', 5, 44000, 'agent prodaje'),
(3, 'Ivan', 'Sarac', 6, 41140, 'agent prodaje'),
(4, 'Milena', 'Nikolic', 4, 36000, 'agent prodaje'),
(5, 'Stefan', 'Stosic', 6, 60000, 'menadzer marketinga'),
(6, 'Stefan', 'Trickovic', 12, 40000, 'salter'),
(7, 'Aleksandar', 'Stojanovic', 6, 45000, 'obezbedjenje'),
(8, 'Petar', 'Bozic', 19, 55000, 'agent prodaje'),
(9, 'Milos', 'Cakic', 4, 32000, 'agent prodaje');

-- --------------------------------------------------------

--
-- Table structure for table `ugovor`
--

CREATE TABLE IF NOT EXISTS `ugovor` (
  `id_ugovor` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date DEFAULT NULL,
  `id_osiguranja` int(11) NOT NULL,
  `id_klijent` int(11) NOT NULL,
  `id_radnik` int(11) NOT NULL,
  PRIMARY KEY (`id_ugovor`),
  KEY `fk_ugovor_osiguranja_idx` (`id_osiguranja`),
  KEY `fk_ugovor_klijent1_idx` (`id_klijent`),
  KEY `fk_ugovor_radnik1_idx` (`id_radnik`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ugovor`
--

INSERT INTO `ugovor` (`id_ugovor`, `datum`, `id_osiguranja`, `id_klijent`, `id_radnik`) VALUES
(1, '2016-02-11', 2, 2, 8),
(2, '2016-02-24', 5, 2, 2),
(3, '2016-02-09', 1, 3, 3),
(4, '2016-03-10', 4, 3, 3);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ugovor`
--
ALTER TABLE `ugovor`
  ADD CONSTRAINT `fk_ugovor_osiguranja` FOREIGN KEY (`id_osiguranja`) REFERENCES `osiguranja` (`id_osiguranja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ugovor_klijent1` FOREIGN KEY (`id_klijent`) REFERENCES `klijent` (`id_klijent`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ugovor_radnik1` FOREIGN KEY (`id_radnik`) REFERENCES `radnik` (`id_radnik`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
